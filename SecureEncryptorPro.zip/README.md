# SecureEncryptorPro

SecureEncryptorPro is an advanced file encryption tool with a modern dark-themed GUI, supporting hybrid AES + RSA encryption.

## Features
- Hybrid AES + RSA encryption
- RSA key generation, save/load
- Modern dark theme
- File encryption & decryption
- Tabbed interface for easy navigation

## Requirements
Install dependencies:
```
pip install cryptography
```

## Usage
Run the application:
```
python SecureEncryptorPro.py
```
